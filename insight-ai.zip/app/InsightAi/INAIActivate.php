<?php

namespace App\InsightAi;

use WP_Error;

class INAIActivate {

	public function __construct() {
        
    }

    public static function activate(){

    }


    

}