<?php


namespace App\InsightAi;

class INAIDeactivate{


    public function __construct() {

    }

    public static function deActivate(){

    }


}