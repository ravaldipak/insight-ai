<form action="options.php" method="post">
    <?php settings_fields( 'insight-ai-settings' ); ?>
    <div id="app" data-base-path="<?php esc_html(INAI_DIR); ?>">


    </div>
</form>